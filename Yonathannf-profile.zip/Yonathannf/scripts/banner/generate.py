#!/usr/bin/env python3
"""Genera banner animado (dark/light) y la tarjeta whoami. Solo stdlib.

Uso (desde la raíz del repo):  python scripts/banner/generate.py
Editá DATA y THEMES para personalizar textos y colores.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / "assets"
def icon_d(n):
    import re
    return re.search(r'd="([^"]+)"', (ASSETS / f"icon-{n}.svg").read_text()).group(1)


MONO = "ui-monospace,SFMono-Regular,Menlo,Consolas,monospace"

DATA = {
    "name": "Jonathan Franco",
    "handle": "Yonathannf",
    "role": "Dev en formación · Ciberseguridad · Logística",
    "location": "Argentina",
    "lines": [
        ("whoami", "jonathan_franco"),
        ("role", "Jefe de Depósito @ Sonnos"),
        ("study", "Tec. Univ. en Programación — UTN (TUPaD)"),
        ("focus", "programación + ciberseguridad + logística"),
        ("status", "construyendo sistemas para la operación real"),
    ],
}

THEMES = {
    "dark": dict(bg="#0A0E14", panel="#0F1620", line="#1E2A3A", text="#D5E0EC",
                 muted="#6F8299", green="#2FD38B", cyan="#2BC4E0", amber="#F2B84B",
                 grid="#122033"),
    "light": dict(bg="#F4F8FB", panel="#FFFFFF", line="#C9D6E2", text="#14202D",
                  muted="#5C6F83", green="#0E9F63", cyan="#0A86A0", amber="#B97A0A",
                  grid="#E3ECF3"),
}


def banner(t):
    W, H = 1180, 340
    rows = []
    y0, dy = 150, 34
    for i, (k, v) in enumerate(DATA["lines"]):
        y = y0 + i * dy
        begin = 0.6 + i * 0.9
        rows.append(
            f'<g opacity="0"><animate attributeName="opacity" from="0" to="1" '
            f'begin="{begin}s" dur="0.4s" fill="freeze"/>'
            f'<text x="60" y="{y}" fill="{t["green"]}" font-size="20" font-weight="700">❯ {k}</text>'
            f'<text x="230" y="{y}" fill="{t["text"]}" font-size="20">{v}</text></g>'
        )
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="t d" font-family="{MONO}">
<title id="t">{DATA["name"]} — {DATA["role"]}</title>
<desc id="d">Banner animado estilo terminal con el perfil de {DATA["name"]}.</desc>
<defs>
<pattern id="grid" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M28 0H0V28" fill="none" stroke="{t["grid"]}"/></pattern>
<linearGradient id="edge" x1="0" x2="1"><stop stop-color="{t["green"]}"/><stop offset="1" stop-color="{t["cyan"]}"/></linearGradient>
<filter id="glow" x="-20%" y="-50%" width="140%" height="200%"><feGaussianBlur stdDeviation="2.5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
</defs>
<rect width="{W}" height="{H}" rx="16" fill="{t["bg"]}"/>
<rect width="{W}" height="{H}" rx="16" fill="url(#grid)"/>
<rect x="12" y="12" width="{W-24}" height="{H-24}" rx="12" fill="{t["panel"]}" fill-opacity=".92" stroke="url(#edge)" stroke-width="1.6"/>
<circle cx="38" cy="38" r="6" fill="#FF5F57"/><circle cx="58" cy="38" r="6" fill="#FEBC2E"/><circle cx="78" cy="38" r="6" fill="#28C840"/>
<text x="{W/2}" y="43" text-anchor="middle" fill="{t["muted"]}" font-size="13">{DATA["handle"]}@sonnos:~ — zsh</text>
<path d="M12 62H{W-12}" stroke="{t["line"]}"/>
<text x="60" y="100" fill="{t["cyan"]}" font-size="38" font-weight="700" filter="url(#glow)">{DATA["name"]}</text>
<text x="60" y="124" fill="{t["muted"]}" font-size="15">{DATA["role"]}  ·  {DATA["location"]}</text>
{"".join(rows)}
<rect x="60" y="{y0 + len(DATA["lines"])*dy - 14}" width="11" height="20" fill="{t["green"]}"><animate attributeName="opacity" values="1;0;1" dur="1s" repeatCount="indefinite"/></rect>
<g transform="translate(860 90)" fill="none" stroke-linecap="round">
<rect x="0" y="0" width="260" height="210" rx="10" fill="{t["bg"]}" stroke="{t["line"]}"/>
<text x="16" y="26" fill="{t["muted"]}" font-size="12" letter-spacing="1.5">SYSTEM.STATUS</text>
<path transform="translate(186 8) scale(.8)" fill="{t["text"]}" stroke="none" d="{icon_d("linux")}"/>
<path transform="translate(214 8) scale(.8)" fill="{t["cyan"]}" stroke="none" d="{icon_d("virtualbox")}"/>
<g font-size="13" fill="{t["text"]}" stroke="none">
<text x="16" y="62">stack</text><text x="244" y="62" text-anchor="end" fill="{t["green"]}">online</text>
<text x="16" y="86">security</text><text x="244" y="86" text-anchor="end" fill="{t["cyan"]}">learning</text>
<text x="16" y="110">stock</text><text x="244" y="110" text-anchor="end" fill="{t["amber"]}">under control</text>
<text x="16" y="134">dispatch</text><text x="244" y="134" text-anchor="end" fill="{t["green"]}">on time</text>
</g>
<path d="M16 196 L52 184 L88 190 L124 172 L160 180 L196 164 L244 168" stroke="{t["green"]}" stroke-width="2.4" filter="url(#glow)" stroke-dasharray="320" stroke-dashoffset="320"><animate attributeName="stroke-dashoffset" from="320" to="0" dur="2.4s" begin="0.4s" fill="freeze"/></path>
</g>
</svg>'''


def whoami(t):
    W, H = 960, 390
    L = lambda x, y, c, s, txt, w="": f'<text x="{x}" y="{y}" fill="{c}" font-size="{s}" {w}>{txt}</text>'
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" aria-labelledby="t d" font-family="{MONO}">
<title id="t">{DATA["name"]} — perfil</title>
<desc id="d">Tarjeta de terminal con ubicación, misión y foco técnico de {DATA["name"]}.</desc>
<defs><linearGradient id="edge" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#2FD38B"/><stop offset="1" stop-color="#2BC4E0"/></linearGradient>
<filter id="glow" x="-20%" y="-30%" width="140%" height="160%"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
<rect width="{W}" height="{H}" rx="18" fill="#0A0E14"/>
<rect x="9" y="9" width="{W-18}" height="{H-18}" rx="13" fill="none" stroke="url(#edge)" stroke-width="2"/>
<circle cx="35" cy="35" r="5" fill="#FF5F57"/><circle cx="54" cy="35" r="5" fill="#FEBC2E"/><circle cx="73" cy="35" r="5" fill="#28C840"/>
{L(98,41,"#6F8299",15,f"{DATA['handle']}  ·  profile shell  ·  online")}
<path d="M29 58H931" stroke="#1E2A3A"/>
<rect x="29" y="78" width="594" height="271" rx="9" fill="#0F1620" stroke="#2FD38B" stroke-opacity=".6" stroke-width="1.5"/>
{L(48,111,"#2FD38B",20,"❯ whoami",'font-weight="700"')}
{L(48,143,"#D5E0EC",18,"jonathan_franco")}{L(250,143,"#6F8299",18,"—")}{L(275,143,"#F2B84B",18,"Dev + Logística")}
<path d="M48 166H604" stroke="#1E2A3A"/>
{L(48,196,"#6F8299",17,"context:")}{L(166,196,"#2BC4E0",17,"Argentina  🇦🇷")}
{L(48,225,"#6F8299",17,"mission:")}{L(166,225,"#2FD38B",17,"llevar la operación real al código")}
{L(48,267,"#2FD38B",20,"❯ ls expertise/",'font-weight="700"')}
{L(48,299,"#2BC4E0",16,"backend/")}{L(214,299,"#D5E0EC",16,"Java · Spring Boot · FastAPI")}
{L(48,326,"#2BC4E0",16,"operaciones/")}{L(214,326,"#D5E0EC",16,"stock · despacho · rutas · posventa")}
<rect x="651" y="78" width="280" height="271" rx="9" fill="#0F1620" stroke="#2FD38B" stroke-opacity=".6" stroke-width="1.5"/>
{L(674,111,"#F2B84B",17,"virtual lab")}
<path transform="translate(690 160) scale(3.6)" fill="#E8EEF5" d="{icon_d("linux")}"/>
<path transform="translate(790 160) scale(3.6)" fill="#4C9BE8" d="{icon_d("virtualbox")}"/>
{L(690,268,"#6F8299",13,"Linux")}{L(790,268,"#6F8299",13,"VirtualBox")}
{L(674,326,"#6F8299",14,"status: aprendiendo siempre")}
</svg>'''


if __name__ == "__main__":
    for name, t in THEMES.items():
        (ASSETS / f"banner-{name}.svg").write_text(banner(t), encoding="utf-8")
    (ASSETS / "whoami-cyber.svg").write_text(whoami(THEMES["dark"]), encoding="utf-8")
    print("ok: banner-dark.svg, banner-light.svg, whoami-cyber.svg")
