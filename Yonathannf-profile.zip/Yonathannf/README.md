<div align="center">

<a href="https://github.com/Yonathannf">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="assets/banner-dark.svg">
    <source media="(prefers-color-scheme: light)" srcset="assets/banner-light.svg">
    <img src="assets/banner-dark.svg" width="960" alt="Perfil de Jonathan Franco">
  </picture>
</a>

<br>

<a href="https://github.com/Yonathannf">
  <img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&amp;weight=700&amp;size=24&amp;duration=2600&amp;pause=900&amp;color=2FD38B&amp;center=true&amp;vCenter=true&amp;width=900&amp;lines=Jonathan+Franco;Programaci%C3%B3n+%7C+Ciberseguridad+%7C+Log%C3%ADstica;Del+dep%C3%B3sito+al+c%C3%B3digo;Estudiante+de+TUPaD+%E2%80%94+UTN" alt="Texto animado con el perfil">
</a>

<img src="https://komarev.com/ghpvc/?username=Yonathannf&style=flat&color=2fd38b&label=profile+views" alt="profile views">

</div>

---

## `$ whoami`

<p align="center">
  <img src="assets/whoami-cyber.svg" width="960" alt="Terminal con el perfil de Jonathan Franco">
</p>

<br>

<div align="center">

## `$ cat tech-stack.yaml`

<table border="1" cellpadding="14" bgcolor="#0F1620">
  <thead>
    <tr><th colspan="2" align="left"><code>Yonathannf:~$ cat tech-stack.yaml</code></th></tr>
  </thead>
  <tbody>
    <tr>
      <td width="50%" valign="top"><code>├─ ✦ backend:</code><br><br>
        <img src="https://skillicons.dev/icons?i=java,spring,python,fastapi,gradle" alt="Java, Spring, Python, FastAPI, Gradle"><br>
        <sub><code>Java 17/21 · Spring Boot · JPA/Hibernate · FastAPI · Gradle</code></sub>
      </td>
      <td width="50%" valign="top"><code>├─ ▣ databases:</code><br><br>
        <img src="https://skillicons.dev/icons?i=mysql,sqlite" alt="MySQL y SQLite"><br>
        <sub><code>MySQL · SQLite · H2</code></sub>
      </td>
    </tr>
    <tr>
      <td valign="top"><code>├─ ◉ frontend:</code><br><br>
        <img src="https://skillicons.dev/icons?i=react,vite,typescript,js,html,css" alt="React, Vite, TypeScript, JavaScript, HTML, CSS"><br>
        <sub><code>React · Vite · TypeScript · JavaScript · HTML · CSS</code></sub>
      </td>
      <td valign="top"><code>├─ ⚙ tools_deploy:</code><br><br>
        <img src="https://skillicons.dev/icons?i=git,github,docker,postman,vercel" alt="Git, GitHub, Docker, Postman, Vercel"><br>
        <sub><code>Git · GitHub · Docker · Postman · Swagger · Vercel · Render · Railway</code></sub>
      </td>
    </tr>
    <tr>
      <td valign="top"><code>├─ ⌁ data_automation:</code><br><br>
        <img src="https://skillicons.dev/icons?i=python,excel" alt="Python y Excel"><br>
        <sub><code>pandas · matplotlib · openpyxl · Excel / LibreOffice</code></sub>
      </td>
      <td valign="top"><code>╰─ ⛨ security_logistics:</code><br><br>
        <img src="assets/icon-linux.svg" height="48" alt="Linux">
        <img src="assets/icon-virtualbox.svg" height="48" alt="VirtualBox"><br>
        <sub><code>Linux · VirtualBox · Ciberseguridad (en formación) · Stock · Despacho · Posventa</code></sub>
      </td>
    </tr>
  </tbody>
  <tfoot>
    <tr><td colspan="2"><code>status: ready&nbsp;&nbsp;·&nbsp;&nbsp;environment: production</code></td></tr>
  </tfoot>
</table>

</div>

---

## `$ ./projects --featured`

| Proyecto | Qué hace | Stack |
|---|---|---|
| **Sonnos · Pedidos y Hoja de Ruta** | Reemplaza planillas Excel enlazadas por una app de pedidos, hojas de ruta y seguimiento de despachos | FastAPI · SQLite |
| **StockIQ** | Sistema de inventario con reposición inteligente (TPI final de TUPaD) | Spring Boot · React |
| **Gestión de Pedidos** | API REST para gestión de órdenes (Programación IV) | Spring Boot · JPA |

---

## `$ kubectl get signals --all-namespaces`

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="assets/radar-dark.svg">
    <source media="(prefers-color-scheme: light)" srcset="assets/radar-light.svg">
    <img src="assets/radar-dark.svg" width="390" alt="Radar de habilidades">
  </picture>&nbsp;
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="assets/radar-langs-dark.svg">
    <source media="(prefers-color-scheme: light)" srcset="assets/radar-langs-light.svg">
    <img src="assets/radar-langs-dark.svg" width="370" alt="Radar de lenguajes">
  </picture>
</p>

<p align="center"><sub><code>signals: skill_radar · language_radar · status: healthy</code></sub></p>

---

## `$ connect --socials`

<div align="center">

<a href="https://www.linkedin.com/in/jonathan-nahuel-franco-administrativo-logística">
  <img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn">
</a>&nbsp;&nbsp;
<a href="https://github.com/Yonathannf">
  <img src="https://img.shields.io/badge/GitHub-2fd38b?style=for-the-badge&logo=github&logoColor=0a0e14" alt="GitHub">
</a>

</div>

<br>

<div align="center">
<sub>Hecho con ☕ y mucho código desde Argentina · @Yonathannf</sub>
</div>
